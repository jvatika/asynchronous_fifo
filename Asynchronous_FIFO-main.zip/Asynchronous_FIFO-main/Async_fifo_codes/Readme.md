This Directory contains all the codes of Asynchronous FIFO
